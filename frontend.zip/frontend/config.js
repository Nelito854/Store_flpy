// CONFIGURAÇÕES DO SITE: altere nome, cor, logo e contatos aqui.
const CONFIG = {
  nomeSite: "Loja APK",
  slogan: "Os melhores APKs, direto pelo link",
  logo: "assets/img/logo.svg",
  corPrimaria: "#16a34a",
  contato: { email: "contato@seusite.com", telegram: "https://t.me/seucanal" },
  aviso: "Baixe apenas de fontes confiáveis. Antes de instalar, ative 'Instalar apps desconhecidos' nas configurações do Android.",
  rodape: "© 2026 Loja APK. Todos os direitos reservados."
};
