// Monta o layout de todas as páginas: menu lateral, topo com busca e rodapé.
// As categorias do menu vêm sozinhas da lista de APKs (src/apps.js).
(function () {
  document.documentElement.style.setProperty("--primary", CONFIG.corPrimaria);

  const categorias = [...new Set(APPS.map(a => a.categoria))];
  const pagina = location.pathname.split("/").pop() || "index.html";
  const item = (href, texto, ativo = false) =>
    `<a href="${href}" class="${ativo ? "ativo" : ""}">${texto}</a>`;

  document.getElementById("app").innerHTML = `
    <aside id="sidebar">
      <div class="marca"><img src="${CONFIG.logo}" alt="">${CONFIG.nomeSite}</div>
      <nav>
        ${item("index.html", "🏠 Início", pagina === "index.html")}
        <p class="grupo">Categorias</p>
        ${categorias.map(c => item("index.html?cat=" + encodeURIComponent(c), c)).join("")}
        <p class="grupo">Ajuda</p>
        ${item("suporte.html", "💬 Suporte", pagina === "suporte.html")}
      </nav>
    </aside>
    <div class="conteudo">
      <header id="topo">
        <button id="menu-btn" aria-label="Abrir menu">☰</button>
        <form action="index.html">
          <input id="busca" name="q" type="search" placeholder="Buscar APK ou desenvolvedor...">
        </form>
      </header>
      <main id="main"></main>
      <footer id="rodape">${CONFIG.rodape}<br><a href="mailto:${CONFIG.contato.email}">${CONFIG.contato.email}</a></footer>
    </div>`;

  document.getElementById("menu-btn").onclick = () =>
    document.getElementById("sidebar").classList.toggle("aberto");
})();
